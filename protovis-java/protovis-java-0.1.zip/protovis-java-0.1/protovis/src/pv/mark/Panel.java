package pv.mark;

public class Panel extends Mark {

	public Panel() {
		this("Panel");
	}
	
	public Panel(String type) {
		super("Panel");
		_panel = this;
	}

}
