package pv.mark.constants;

public interface Interpolate {

	public static final String Linear = "linear";
	public static final String StepAfter = "step-after";
	public static final String StepBefore = "step-before";
	
}
