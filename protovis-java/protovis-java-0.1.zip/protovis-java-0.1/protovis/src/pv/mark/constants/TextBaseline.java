package pv.mark.constants;

public interface TextBaseline {

	public static final String Bottom = "bottom";
	public static final String Top = "top";
	public static final String Middle = "middle";
	
}
