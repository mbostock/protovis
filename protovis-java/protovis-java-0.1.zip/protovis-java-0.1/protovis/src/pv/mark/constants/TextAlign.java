package pv.mark.constants;

public interface TextAlign {

	public static final String Left = "left";
	public static final String Right = "right";
	public static final String Center = "center";
	
}
