package pv.mark.constants;

public interface Shape {

	public static final String Circle = "circle";
	public static final String Square = "square";
	public static final String Triangle = "triangle";
	public static final String Cross = "cross";
	public static final String X = "x";
	public static final String Diamond = "diamond";
	public static final String Point = "point";
	
}
