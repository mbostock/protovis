PROTOVIS-EXAMPLES README

This project contains sample applications and tests for the Protovis-Java
research prototype. The project contains two packages:

edu.stanford.vis.examples -> Example apps to showcase Protovis functions
edu.stanford.vis.test     -> Simple tests of Protovis marks

All examples are dependent on the "protovis" project and its dependencies.